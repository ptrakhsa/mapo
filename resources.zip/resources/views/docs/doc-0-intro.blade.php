@extends('layouts.docs-panel')
@section('content')
    <h3>Architecture</h3>
    <img src="/assets/images/contents/architecture.png" class="img-fluid" />
@endsection
