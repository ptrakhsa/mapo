<?php $__env->startSection('title', 'Organizer Dashboard'); ?>

<?php $__env->startSection('head'); ?>
    <style>
        .fab-add-event {
            position: fixed;
            bottom: 40px;
            right: 40px;
            width: 50px;
            height: 50px;
            cursor: pointer;
            border-radius: 50%;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: bold;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="d-flex justify-content-between align-items-center px-3 py-3 bg-white">
        <div class="dropdown-toggle d-flex align-items-center dropdown" id="dropdownMenuButton" data-bs-toggle="dropdown"
            aria-haspopup="true" aria-expanded="false" style="cursor: pointer">
            <div class="avatar bg-info avatar-lg bg-warning me-3">
                <img src="/assets/images/faces/1.jpg" alt="" srcset="">
            </div>
            <h4><?php echo e(auth()->guard('organizer')->user()->name); ?></h4>
        </div>
        
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <a class="dropdown-item" href="/organizer/profile">Profile</a>
            <a class="dropdown-item" href="/organizer/toc">TOC</a>
        </div>


        <div class="d-flex align-content-center">
            <a class="btn" href="/organizer/activity">Activity</a>
            <form action="/organizer/logout" method="POST">
                <?php echo csrf_field(); ?>
                <input type="submit" class="btn" value="Logout">
            </form>
        </div>
    </div>

    

    <div class="d-flex justify-content-center row mx-3 mt-4">
        <?php $__empty_1 = true; $__currentLoopData = $my_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-xl-4 col-md-6 col-sm-12">
                <div class="card">
                    <div class="card-content">
                        <img style="max-height: 400px;object-fit: contain;" class="img-fluid w-100"
                            src="<?php echo e($event->photo); ?>" alt="Card image cap">
                        <div class="card-body">
                            <h4 class="card-title"><?php echo e($event->name); ?></h4>
                            <span class="badge bg-light-primary mb-3"><?php echo e($event->category->name); ?></span>
                            <p class="card-text truncate-threeline">
                                <?php echo e($event->description); ?>

                            </p>
                            <p class="card-text">
                                <small>
                                    <span class="fa-fw select-all fas"></span>
                                    <?php echo e(date_format(date_create($event->start_date), 'H:i A, j F Y')); ?>

                                </small>
                                <br>
                                <small>
                                    <span class="fa-fw select-all fas"></span>
                                    <?php echo e($event->location); ?>

                                </small>
                            </p>


                        </div>

                    </div>
                    <div class="card-footer d-flex justify-content-between">
                        <div>

                            <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'badge',
                                'bg-secondary' => $event->status->status == 'waiting',
                                'bg-warning' => $event->status->status == 'rejected',
                                'bg-info' => $event->status->status == 'verified',
                                'bg-success' => $event->status->status == 'done',
                                'bg-danger' => $event->status->status == 'takedown',
                            ]) ?>"><?php echo e($event->status->status); ?></span>

                        </div>

                        <div>
                            <?php if(in_array($event->status->status, ['verified', 'done', 'takedown'])): ?>
                                <a href="/organizer/event/detail/<?php echo e($event->id); ?>"
                                    class="btn btn-light-primary">Detail</a>
                            <?php else: ?>
                                <form action="/organizer/event/delete/<?php echo e($event->id); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                    <input type="submit" id="delete-form-submit">
                                </form>

                                <button onclick="showDeleteDialog()" class="btn btn-light-danger">hapus</button>
                                <script>
                                    async function showDeleteDialog() {
                                        Swal.fire({
                                            title: 'Do you want to delete this event ?',
                                            showCancelButton: true,
                                            confirmButtonText: 'Yes',
                                            denyButtonText: 'No',
                                            customClass: {
                                                cancelButton: 'order-1 right-gap',
                                                confirmButton: 'order-2',
                                            }
                                        }).then((result) => {
                                            if (result.isConfirmed) {
                                                document.getElementById('delete-form-submit').click()
                                            }
                                        })
                                    }
                                </script>
                                <a href="/organizer/event/edit/<?php echo e($event->id); ?>" class="btn btn-light-primary">Edit</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div style="height: 100vh;" class="d-flex justify-content-center align-items-center flex-column">
                <h3>Upps!</h3>
                <p>Looks like you don't have any events for now!</p>
                <a href="/organizer/create" class="btn btn-primary">Create an Event!</a>
            </div>
        <?php endif; ?>

        <a href="/organizer/create" class="bg-primary fab-add-event">+</a>
    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mapo\resources\views/organizer/dashboard.blade.php ENDPATH**/ ?>