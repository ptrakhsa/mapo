
<?php $__env->startSection('content'); ?>
<h3>Architecture</h3>
<img src="/assets/images/contents/architecture.png" class="img-fluid" />
hey
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.docs-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mapo\resources\views/docs/doc-4-uwiii.blade.php ENDPATH**/ ?>