<?php $__env->startSection('title', 'Sorry'); ?>


<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-center flex-column align-items-center" style="height: 100vh;">
        <div class="d-flex align-items-center" style="font-size: 40px;">
            <b><?php echo e($res['code']); ?></b> <span class="mx-3">|</span> <?php echo e($res['message']); ?>

        </div>

        <?php if($res['action']): ?>
            <a class="btn btn-primary mt-4" href="<?php echo e($res['action']['url']); ?>"><?php echo e($res['action']['text']); ?></a>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mapo\resources\views/errors/exception.blade.php ENDPATH**/ ?>