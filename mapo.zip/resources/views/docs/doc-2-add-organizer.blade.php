@extends('layouts.docs-panel')
@section('content')
    <h3>Add organizer</h3>
@endsection
