<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('head'); ?>
    <style>
        .btn:focus,
        .btn:active {
            outline: none !important;
            box-shadow: none;
        }

        .date-label {
            position: absolute;
            top: 0px;
            left: 0px;
            background-color: rgb(189, 72, 72);
            color: white;
            font-weight: bold;
            padding-left: 10px;
            padding-right: 10px;
            border-bottom-right-radius: 10px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-heading">

        
        
        <div class="page-title">
            <div class="row">
                <div class="col-12 col-md-6 order-md-1 order-last">
                    <h3>Dashboard</h3>
                    <p class="text-subtitle text-muted">Incoming and On Going events</p>
                    <div class="mb-5 d-flex">

                        <a href="/admin/dashboard?status=incoming"
                            class="btn btn-sm rounded-pill <?php echo e($current_status == 'incoming' ? 'btn-primary' : 'btn-outline-primary'); ?>">Incoming</a>
                        <a href="/admin/dashboard?status=upcoming"
                            class="mx-1 btn btn-sm rounded-pill <?php echo e($current_status == 'upcoming' ? 'btn-primary' : 'btn-outline-primary'); ?>">Ongoing</a>


                        

                        <?php if($current_status == 'upcoming'): ?>
                            
                            <div style="background-color: rgb(212, 217, 221); width: 2px;height: 30px" class="mx-2">
                            </div>
                            

                            <a href="/admin/dashboard?status=upcoming&date=week"
                                class="<?php echo e($current_date == 'week' ? 'btn-success' : 'btn-outline-success'); ?> btn btn-sm rounded-pill">This
                                week</a>
                            <a href="/admin/dashboard?status=upcoming&date=month"
                                class="<?php echo e($current_date == 'month' ? 'btn-success' : 'btn-outline-success'); ?> btn btn-sm mx-1 rounded-pill">This
                                month</a>
                            <a href="/admin/dashboard?status=upcoming&date=year"
                                class="<?php echo e($current_date == 'year' ? 'btn-success' : 'btn-outline-success'); ?> btn btn-sm rounded-pill">This
                                year</a>
                        <?php endif; ?>

                    </div>

                </div>

            </div>

        </div>
        
        



        
        <section id="content-types">
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $current_submitted_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-xl-4 col-md-6 col-sm-12">
                        <div class="card">

                            <div class="card-content">
                                <div class="date-label" style="border-radius: 5px; margin: 10px 0px 0px 10px ;">
                                    <?php echo e(\Carbon\Carbon::parse($event->start_date)->diffForHumans()); ?>

                                </div>
                                <img style="max-height: 400px;object-fit: contain; border-radius:10px 10px 0px 0px; linear-gradient(center top , #FFFFFF, #DDDDDD);"
                                    class="img-fluid w-100" src="<?php echo e($event->photo); ?>" alt="Card image cap">
                                <div class="card-body">
                                    <h4 class="card-title"><?php echo e($event->name); ?></h4>
                                    <span class="badge bg-light-primary mb-3"><?php echo e($event->category->name); ?></span>
                                    <p class="card-text truncate-threeline">
                                        <?php echo e($event->description); ?>

                                    </p>
                                    <p class="card-text">
                                        <small>
                                            <span class="fa-fw select-all fas"></span>
                                            <?php echo e(date_format(date_create($event->start_date), 'l, j F Y')); ?>

                                        </small>
                                        <br>
                                        <small>
                                            <span class="fa-fw select-all fas"></span>
                                            <?php echo e(date_format(date_create($event->start_date), 'H:i A')); ?> -
                                            <?php echo e(date_format(date_create($event->end_date), 'H:i A')); ?>

                                        </small>
                                        <br>
                                        <small>
                                            <span class="fa-fw select-all fas"></span>
                                            <?php echo e($event->location); ?>

                                        </small>
                                    </p>


                                </div>

                            </div>
                            <div class="card-footer d-flex justify-content-between">
                                <span><?php echo e($event->organizer->name); ?></span>
                                <a href="/admin/event/detail/<?php echo e($event->id); ?>" class="btn btn-light-primary">Read
                                    More</a>
                            </div>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <hr>
                    <div>Waiting for something new ..</div>
                <?php endif; ?>
            </div>
        </section>
        

    </div>

    <script>
        function messageNotifier(message) {
            Toastify({
                text: message,
                duration: 3000,
                gravity: "bottom",
                position: "center",
                close: true,
                backgroundColor: '#4F6467',
            }).showToast();
        }
        // note render 'false' is equal with false in js 
        let message = {
            {
                session() - > has('message') ? Illuminate\ Support\ Js::from(session() - > get('message')) : 'false'
            }
        };
        if (message) {
            messageNotifier(message)
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mapo\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>