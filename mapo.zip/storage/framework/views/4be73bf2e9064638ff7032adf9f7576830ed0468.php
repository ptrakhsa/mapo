<?php $__env->startSection('title', 'Events'); ?>


<?php $__env->startSection('content'); ?>
    <div class="page-heading">

        
        
        <div class="page-title">
            <div class="row">
                <div class="col-12 col-md-6 order-md-1 order-last">
                    <h3>Events</h3>
                    <p class="text-subtitle text-muted">List of events group by event status</p>
                </div>
            </div>
        </div>
        
        



        
        <section id="content-types">

            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h4 class="card-title"><?php echo e($current_status); ?> events</h4>
                    <select name="" id="" class="form-select" style="width:200px"
                        onchange="changeEventStatus(this)">
                        <option <?php echo e($current_status == 'all' ? 'selected' : ''); ?> value="all">All</option>
                        <option <?php echo e($current_status == 'verified' ? 'selected' : ''); ?> value="verified">Verified</option>
                        <option <?php echo e($current_status == 'done' ? 'selected' : ''); ?> value="done">Done</option>
                        <option <?php echo e($current_status == 'rejected' ? 'selected' : ''); ?> value="rejected">Rejected</option>
                        <option <?php echo e($current_status == 'takedown' ? 'selected' : ''); ?> value="takedown">Takedown</option>
                    </select>
                    <script>
                        function changeEventStatus(e) {
                            window.location = `/admin/events?status=${e.value}`
                        }
                    </script>
                </div>
                <div class="card-content">
                    <!-- Table with no outer spacing -->
                    <div class="table-responsive">
                        <table class="table mb-0 table-lg">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Start date</th>
                                    <th>Location</th>
                                    <th>Organizer</th>
                                    <th class="<?php echo e($current_status != 'all' ? 'd-none' : ''); ?>">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                                        <td class="text-bold-500">
                                            <a href="/admin/event/show/detail/<?php echo e($event->id); ?>"
                                                style="font-weight: bold;"><?php echo e($event->name); ?></a>
                                        </td>
                                        <td><?php echo e($event->start_date); ?></td>
                                        <td class="text-bold-500"><?php echo e($event->location); ?></td>
                                        <td><?php echo e($event->organizer->name); ?></td>
                                        <td class="<?php echo e($current_status != 'all' ? 'd-none' : ''); ?>">
                                            <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                                'badge',
                                                'bg-secondary' => $event->status->status == 'waiting',
                                                'bg-warning' => $event->status->status == 'rejected',
                                                'bg-info' => $event->status->status == 'verified',
                                                'bg-success' => $event->status->status == 'done',
                                                'bg-danger' => $event->status->status == 'takedown',
                                            ]) ?>">
                                                <?php echo e($event->status->status); ?>

                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td class="text-muted text-center" colspan="5">No data</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
        

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mapo\resources\views/admin/events.blade.php ENDPATH**/ ?>