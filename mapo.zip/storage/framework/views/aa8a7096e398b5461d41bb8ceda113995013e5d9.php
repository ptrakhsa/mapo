<?php $__env->startSection('title', 'Activity'); ?>


<?php $__env->startSection('content'); ?>
    
    <div class="d-flex justify-content-between align-items-center px-3 py-3 bg-white">
        <div class="dropdown-toggle d-flex align-items-center dropdown" id="dropdownMenuButton" data-bs-toggle="dropdown"
            aria-haspopup="true" aria-expanded="false" style="cursor: pointer">
            <div class="avatar bg-info avatar-lg bg-warning me-3">
                <img src="/assets/images/faces/1.jpg" alt="" srcset="">
            </div>
            <h4><?php echo e(auth()->guard('organizer')->user()->name); ?></h4>
        </div>
        
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <a class="dropdown-item" href="/organizer/profile">Profile</a>
            <a class="dropdown-item" href="/organizer/toc">TOC</a>
        </div>


        <div class="d-flex align-content-center">
            <a class="btn" href="/organizer/dashboard">Dashboard</a>
            <a class="btn" href="/organizer/activity">Activity</a>
            <form action="/organizer/logout" method="POST">
                <?php echo csrf_field(); ?>
                <input type="submit" class="btn" value="Logout">
            </form>
        </div>
    </div>


    
    <div class="container mt-4">
        Your activities
        <div class="d-flex justify-content-center row mt-4">

            <?php $__empty_1 = true; $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="card pa">
                    <div class="media">
                        <div class="media-body py-3 px-3">
                            <h5 class="mt-0"><?php echo e($activity->status); ?></h5>
                            <small class="text-muted">3 juni 2020</small>
                            <br>
                            <br>

                            <span>
                                <?php if($activity->status == 'waiting'): ?>
                                    Admin still review <strong><?php echo e($activity->event_name); ?></strong> event
                                <?php endif; ?>

                                <?php if($activity->status == 'rejected'): ?>
                                    Admin rejected your <strong><?php echo e($activity->event_name); ?></strong> event because
                                    <strong><?php echo e($activity->reason); ?></strong>
                                <?php endif; ?>

                                <?php if($activity->status == 'verified'): ?>
                                    Congrats <strong><?php echo e($activity->event_name); ?></strong> has been verified
                                <?php endif; ?>

                                <?php if($activity->status == 'takedown'): ?>
                                    Sorry <strong><?php echo e($activity->event_name); ?></strong> has been takedown by admin because
                                    <strong><?php echo e($activity->reason); ?></strong>
                                <?php endif; ?>

                            </span>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <span class="text-muted text-center mt-4">no activities</span>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mapo\resources\views/organizer/activity.blade.php ENDPATH**/ ?>