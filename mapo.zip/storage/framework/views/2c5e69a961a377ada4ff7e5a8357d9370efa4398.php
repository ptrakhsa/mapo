<?php $__env->startSection('title', 'Event Detail'); ?>



<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between align-items-center px-3 py-3 bg-white">
    <div class="dropdown-toggle d-flex align-items-center dropdown" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="cursor: pointer">
        <div class="avatar bg-info avatar-lg bg-warning me-3">
            <img src="/assets/images/faces/1.jpg" alt="" srcset="">
        </div>
        <h4><?php echo e(auth()->guard('organizer')->user()->name); ?></h4>
    </div>
    
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <a class="dropdown-item" href="/organizer/profile">Profile</a>
        <a class="dropdown-item" href="/organizer/toc">TOC</a>
    </div>


    <div class="d-flex align-content-center">
        <a class="btn" href="/organizer/dashboard">Dashboard</a>
        <a class="btn" href="/organizer/activity">Activity</a>
        <form action="/organizer/logout" method="POST">
            <?php echo csrf_field(); ?>
            <input type="submit" class="btn" value="Logout">
        </form>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-9">
            <div class="card px-4 py-4 mx-3 my-3">
                <div class="card-content">
                    <h3><?php echo e($event->name); ?></h3>
                    <span class="badge bg-light-primary mb-3"><?php echo e($event->category_name); ?></span>

                    <img src="<?php echo e($event->photo); ?>" class="img-fluid w-100" alt="event image">
                    <div class="card-body">
                        <p class="text-subtitle"><?php echo e($event->description); ?></p>

                        <div class="mb-3">
                            <?php echo $event->content; ?>

                        </div>
                        <small>
                            <span class="fa-fw select-all fas"></span>
                            <span><?php echo e(date_format(date_create($event->start_date), 'H:i A, j F Y')); ?> -
                                <?php echo e(date_format(date_create($event->end_date), 'H:i A, j F Y')); ?></span>
                        </small>
                        <br>
                        <small>
                            <span class="fa-fw select-all fas"></span>
                            <span><?php echo e($event->location); ?></span>
                        </small>
                        <br>

                    </div>

                    <div class="card-footer d-flex justify-content-between">
                        <span>Held by <h5> <?php echo e($event->organizer_name); ?></h5></span>
                        <a target="_blank" href="<?php echo e($event->link); ?>" class="btn btn-primary">Gmaps route</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-3" style="position: relative;">
            <div class="card px-4 py-4 mx-3 my-3">
                <div class="card-content">
                    <h6 class="">Submission history</h6>
                    <ul>

                        <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="mb-3">
                            <strong><?php echo e($sub->status); ?></strong>
                            <br>
                            <small>
                                <span class="fa-fw select-all fas"></span>
                                <span><?php echo e($sub->created_at ?? '-'); ?></span>
                            </small>

                            <br>

                            <?php if($sub->status == 'rejected' || $sub->status == 'takedown'): ?>
                            <small>
                                <span class="bi bi-file-earmark-medical-fill"></span>
                                <span style="color: rgb(205, 56, 56)"><?php echo e($sub->reason ?? '-'); ?></span>
                            </small>
                            <?php endif; ?>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mapo\resources\views/organizer/event-detail.blade.php ENDPATH**/ ?>