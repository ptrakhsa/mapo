<?php $__env->startSection('title', 'Organizer Profile'); ?>


<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        
        <section id="content-types" class="card px-5 py-5">
            
            <div class="d-flex justify-content-between">
                <div class="d-flex align-items-center">
                    <div class="avatar avatar-xl me-4">
                        <img src="/assets/images/faces/1.jpg" alt="" srcset="">
                    </div>
                    <div class="d-flex flex-column">
                        <h4><?php echo e($organizer->name); ?></h4>
                        <small style="line-height: 1.2;"><?php echo e($organizer->email); ?></small>
                        <small><?php echo e($organizer->address); ?></small>
                    </div>
                </div>
            </div>


            
            <div class="mt-2">
                <small>
                    Joined at <?php echo e(date_format(date_create($organizer->created_at), 'H:i A j F Y')); ?>, total
                    <?php echo e(count($organizer->events)); ?> events submitted
                </small>
            </div>

            <?php if(count($event_statuses) !== 0): ?>
                <div class="mt-4">
                    
                    <a href="/admin/organizer/<?php echo e($organizer->id); ?>/events?status=all" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'btn',
                        'btn-sm',
                        'rounded-pill',
                        'btn-primary' => $recent_status_query == 'all',
                    ]) ?>">
                        all events
                    </a>

                    <?php $__currentLoopData = $event_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="/admin/organizer/<?php echo e($organizer->id); ?>/events?status=<?php echo e($status); ?>"
                            class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'btn',
                                'btn-sm',
                                'rounded-pill',
                                'btn-primary' => $recent_status_query == $status,
                            ]) ?>">
                            <?php echo e($status); ?>

                            <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'badge',
                                'bg-transparent' => $recent_status_query == $status,
                                'bg-secondary' => $recent_status_query != $status,
                            ]) ?>"><?php echo e($count); ?></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    
                    <div class="row mt-3 py-3">
                        <?php $__empty_1 = true; $__currentLoopData = $events_by_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-xl-4 col-md-6 col-sm-12">
                                <div class="card" style="border: 1px solid #cdd0d2;">
                                    <div class="card-content">
                                        <img style="max-height: 400px;object-fit: contain;" class="img-fluid w-100"
                                            src="<?php echo e($event->photo); ?>" alt="Card image cap">
                                        <div class="card-body">
                                            <h4 class="card-title"><?php echo e($event->name); ?></h4>
                                            <span class="badge bg-light-primary mb-3"><?php echo e($event->category->name); ?></span>
                                            <p class="card-text truncate-threeline">
                                                <?php echo e($event->description); ?>

                                            </p>
                                            <p class="card-text">
                                                <small>
                                                    <span class="fa-fw select-all fas"></span>
                                                    <?php echo e(date_format(date_create($event->start_date), 'H:i A, j F Y')); ?>

                                                </small>
                                                <br>
                                                <small>
                                                    <span class="fa-fw select-all fas"></span>
                                                    <?php echo e($event->location); ?>

                                                </small>
                                            </p>
                                        </div>
                                    </div>

                                    <div class="card-footer d-flex justify-content-between">
                                        <div>
                                            <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                                'badge',
                                                'bg-secondary' => $event->status->status == 'waiting',
                                                'bg-warning' => $event->status->status == 'rejected',
                                                'bg-info' => $event->status->status == 'verified',
                                                'bg-success' => $event->status->status == 'done',
                                                'bg-danger' => $event->status->status == 'takedown',
                                            ]) ?>"><?php echo e($event->status->status); ?></span>
                                        </div>
                                        <div>
                                            <a href="/admin/event/show/detail/<?php echo e($event->id); ?>"
                                                class="btn btn-light-primary">Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div>No data</div>
                        <?php endif; ?>
                    </div>

                </div>
            <?php endif; ?>
        </section>
        

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mapo\resources\views/admin/organizer-with-events.blade.php ENDPATH**/ ?>